export function AchievementsSection() {
  const achievements = [
    {
      number: '15+',
      label: 'Laundry Services',
      description: 'Professional cleaning solutions'
    },
    {
      number: '240+',
      label: 'Happy Customers',
      description: 'Satisfied with our services'
    },
    {
      number: '2+ Yrs',
      label: 'Experience',
      description: 'In the laundry industry'
    }
  ];

  return (
    <section className="bg-blue-500 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-white mb-4">Our Achievements</h2>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8 text-center">
          {achievements.map((achievement, index) => (
            <div key={index} className="text-white">
              <div className="text-4xl font-bold mb-2">{achievement.number}</div>
              <div className="text-xl font-semibold mb-1">{achievement.label}</div>
              <div className="text-blue-100 text-sm">{achievement.description}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}