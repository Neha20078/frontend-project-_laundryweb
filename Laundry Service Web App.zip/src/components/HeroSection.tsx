import { Button } from './ui/button';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function HeroSection() {
  const handleBookService = () => {
    const servicesSection = document.getElementById('services');
    servicesSection?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="home" className="bg-gradient-to-br from-blue-50 to-white py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 leading-tight">
              Revitalize Your Clothes with Expert{' '}
              <span className="text-blue-500">Laundry Services!</span>
            </h1>
            <p className="text-lg text-gray-600 leading-relaxed">
              From premium dry cleaning to swift wash and fold, we deliver care and convenience. 
              Schedule a pickup and rediscover the freshness of your clothes today!
            </p>
            <Button 
              onClick={handleBookService}
              className="bg-blue-500 hover:bg-blue-600 text-white px-8 py-3 text-lg"
            >
              📅 Book a service today!
            </Button>
          </div>
          
          <div className="flex justify-center">
            <ImageWithFallback
              src="https://static.vecteezy.com/system/resources/previews/026/721/193/non_2x/washing-machine-and-laundry-laundry-sticker-png.png"
              alt="Modern laundry equipment"
              className="w-full max-w-md h-auto rounded-lg shadow-lg"
            />
          </div>
        </div>
      </div>
    </section>
  );
}