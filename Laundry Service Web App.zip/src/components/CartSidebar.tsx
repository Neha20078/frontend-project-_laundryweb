import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { X } from 'lucide-react';
import { CartItem } from './ServicesSection';
import emailjs from '@emailjs/browser';
import { toast } from 'sonner@2.0.3';

interface CartSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onRemoveFromCart: (serviceId: string) => void;
}

export function CartSidebar({ isOpen, onClose, cartItems, onRemoveFromCart }: CartSidebarProps) {
  const [customerDetails, setCustomerDetails] = useState({
    fullName: '',
    email: '',
    phone: ''
  });
  const [isBooking, setIsBooking] = useState(false);

  const totalAmount = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  const handleInputChange = (field: string, value: string) => {
    setCustomerDetails(prev => ({ ...prev, [field]: value }));
  };

  const handleBookNow = async () => {
    if (!customerDetails.fullName || !customerDetails.email || !customerDetails.phone) {
      toast.error('Please fill in all customer details');
      return;
    }

    if (cartItems.length === 0) {
      toast.error('Please add items to your cart');
      return;
    }

    setIsBooking(true);

    try {
      // Prepare email data
      const orderDetails = cartItems.map(item => 
        `${item.icon} ${item.name} x${item.quantity} = ₹${item.price * item.quantity}`
      ).join('\n');

      const emailData = {
        customer_name: customerDetails.fullName,
        customer_email: customerDetails.email,
        customer_phone: customerDetails.phone,
        order_details: orderDetails,
        total_amount: totalAmount,
        order_date: new Date().toLocaleDateString(),
        order_time: new Date().toLocaleTimeString()
      };

      // Initialize EmailJS (you'll need to replace these with your actual values)
      await emailjs.send(
        'YOUR_SERVICE_ID', // Replace with your EmailJS service ID
        'YOUR_TEMPLATE_ID', // Replace with your EmailJS template ID
        emailData,
        'YOUR_PUBLIC_KEY' // Replace with your EmailJS public key
      );

      toast.success('Order placed successfully! Confirmation email sent.');
      
      // Reset form and close cart
      setCustomerDetails({ fullName: '', email: '', phone: '' });
      onClose();
      
    } catch (error) {
      console.error('Email sending failed:', error);
      toast.error('Failed to send confirmation email. Please try again.');
    } finally {
      setIsBooking(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black bg-opacity-50" onClick={onClose} />
      
      {/* Sidebar */}
      <div className="absolute right-0 top-0 h-full w-full max-w-md bg-white shadow-xl">
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b">
            <h2 className="text-lg font-semibold">Added Items</h2>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-5 h-5" />
            </Button>
          </div>

          {/* Cart Items */}
          <div className="flex-1 overflow-y-auto p-4">
            {cartItems.length === 0 ? (
              <p className="text-gray-500 text-center py-8">Your cart is empty</p>
            ) : (
              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm font-medium text-gray-500">
                    <span>S.No</span>
                    <span>Service Name</span>
                    <span>Price</span>
                  </div>
                  {cartItems.map((item, index) => (
                    <div key={item.id} className="flex justify-between items-center py-2 border-b">
                      <span className="text-sm">{index + 1}</span>
                      <div className="flex-1 px-2">
                        <span className="text-sm">{item.name}</span>
                        <span className="text-xs text-gray-500 block">Qty: {item.quantity}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-sm font-medium">₹{item.price * item.quantity}.00</span>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => onRemoveFromCart(item.id)}
                          className="text-red-500 hover:text-red-700 ml-2"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="border-t pt-4">
                  <div className="flex justify-between items-center font-bold text-lg">
                    <span>Total Amount</span>
                    <span className="text-red-500">₹{totalAmount}.00</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Booking Form */}
          <div className="border-t p-4 space-y-4">
            <h3 className="font-semibold">Book Now</h3>
            
            <div className="space-y-3">
              <div>
                <Label htmlFor="fullName">Full Name</Label>
                <Input
                  id="fullName"
                  value={customerDetails.fullName}
                  onChange={(e) => handleInputChange('fullName', e.target.value)}
                  placeholder="Enter your full name"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label htmlFor="email">Email ID</Label>
                  <Input
                    id="email"
                    type="email"
                    value={customerDetails.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                    placeholder="Email"
                  />
                </div>
                <div>
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={customerDetails.phone}
                    onChange={(e) => handleInputChange('phone', e.target.value)}
                    placeholder="Phone"
                  />
                </div>
              </div>
            </div>

            <Button 
              onClick={handleBookNow}
              disabled={isBooking || cartItems.length === 0}
              className="w-full bg-blue-500 hover:bg-blue-600 text-white"
            >
              {isBooking ? 'Booking...' : 'Book now'}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}