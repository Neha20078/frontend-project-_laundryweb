import { ImageWithFallback } from './figma/ImageWithFallback';

export function FeaturesSection() {
  const features = [
    {
      title: 'Premium Services',
      description: 'Expert garment care and quality detergent for top-tier',
      image: 'https://th.bing.com/th/id/OIP.inYcnpj3LNCcuL_mZ8FzqgHaHy?w=157&h=180&c=7&r=0&o=5&pid=1.7'
    },
    {
      title: 'Quick Support',
      description: 'Customer support with quick response time',
      image: 'https://cdn-icons-png.flaticon.com/512/6146/6146691.png'
    },
    {
      title: 'Hassle Free Delivery',
      description: 'Doorstep delivery for your conveyance and ease',
      image: 'https://toppng.com/public/uploads/preview/o-hassle-delivery-11563795945qwd1y8k2k1.png'
    },
    {
      title: 'Affordable Prices',
      description: 'Best-in-price service with quality assurance',
      image: 'https://tse1.mm.bing.net/th/id/OIP.WeIyILVaSgmoGiyfmUcz7QAAAA?rs=1&pid=ImgDetMain&o=7&rm=3'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full overflow-hidden bg-gray-100">
                <ImageWithFallback
                  src={feature.image}
                  alt={feature.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">{feature.title}</h3>
              <p className="text-sm text-gray-600 leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}