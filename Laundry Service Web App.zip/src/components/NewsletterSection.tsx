import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { toast } from 'sonner@2.0.3';

export function NewsletterSection() {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !name) {
      toast.error('Please fill in both fields');
      return;
    }
    
    // Here you would integrate with your newsletter service
    toast.success('Successfully subscribed to our newsletter!');
    setEmail('');
    setName('');
  };

  return (
    <section className="bg-gradient-to-r from-blue-500 to-blue-600 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Subscribe to our newsletter.
          </h2>
          
          <form onSubmit={handleSubscribe} className="max-w-md mx-auto">
            <div className="flex flex-col sm:flex-row gap-4 mt-8">
              <Input
                type="text"
                placeholder="Full name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="bg-white/90 border-0 placeholder:text-gray-500"
              />
              <Input
                type="email"
                placeholder="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="bg-white/90 border-0 placeholder:text-gray-500"
              />
              <Button 
                type="submit"
                className="bg-white text-blue-600 hover:bg-gray-100 font-semibold px-8"
              >
                Subscribe
              </Button>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
}