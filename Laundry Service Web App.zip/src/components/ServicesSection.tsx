import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Plus, Minus } from 'lucide-react';

export interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  icon: string;
}

interface ServicesSectionProps {
  cartItems: CartItem[];
  onAddToCart: (service: Omit<CartItem, 'quantity'>) => void;
  onRemoveFromCart: (serviceId: string) => void;
  onShowCart: () => void;
}

export function ServicesSection({ cartItems, onAddToCart, onRemoveFromCart, onShowCart }: ServicesSectionProps) {
  const services = [
    { id: 'dry-cleaning', name: 'Dry Cleaning', price: 200, icon: '🧥' },
    { id: 'wash-fold', name: 'Wash & Fold', price: 100, icon: '👕' },
    { id: 'ironing', name: 'Ironing', price: 30, icon: '👔' },
    { id: 'stain-removal', name: 'Stain Removal', price: 500, icon: '🧴' },
    { id: 'leather-suede', name: 'Leather & Suede Cleaning', price: 1999, icon: '🧥' },
    { id: 'wedding-dress', name: 'Wedding Dress Cleaning', price: 2800, icon: '👰' },
  ];

  const getItemQuantity = (serviceId: string) => {
    const item = cartItems.find(item => item.id === serviceId);
    return item ? item.quantity : 0;
  };

  const handleAddItem = (service: typeof services[0]) => {
    onAddToCart({
      id: service.id,
      name: service.name,
      price: service.price,
      icon: service.icon
    });
  };

  const handleRemoveItem = (serviceId: string) => {
    onRemoveFromCart(serviceId);
  };

  return (
    <section id="services" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Services</h2>
          <p className="text-gray-600 mb-6">
            Click On The Add To Cart Button To Add The Services To Your Cart
          </p>
          <Button 
            onClick={onShowCart}
            className="bg-blue-500 hover:bg-blue-600 text-white"
          >
            💡 Add the items to the cart and book now
          </Button>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service) => {
            const quantity = getItemQuantity(service.id);
            
            return (
              <Card key={service.id} className="p-6 hover:shadow-lg transition-shadow">
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <span className="text-2xl">{service.icon}</span>
                      <div>
                        <h3 className="font-semibold text-gray-900">{service.name}</h3>
                        <p className="text-blue-600 font-bold">₹{service.price}.00</p>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    {quantity > 0 ? (
                      <div className="flex items-center space-x-3">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleRemoveItem(service.id)}
                          className="text-red-500 border-red-500 hover:bg-red-50"
                        >
                          <Minus className="w-4 h-4" />
                        </Button>
                        <span className="font-semibold">{quantity}</span>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleAddItem(service)}
                          className="text-green-600 border-green-600 hover:bg-green-50"
                        >
                          <Plus className="w-4 h-4" />
                        </Button>
                      </div>
                    ) : (
                      <Button
                        onClick={() => handleAddItem(service)}
                        variant="outline"
                        className="text-blue-600 border-blue-600 hover:bg-blue-50"
                      >
                        Add Item ⊕
                      </Button>
                    )}
                    
                    {quantity > 0 && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleRemoveItem(service.id)}
                        className="text-red-500 border-red-500 hover:bg-red-50"
                      >
                        Remove Item
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}