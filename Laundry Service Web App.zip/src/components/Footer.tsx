import { Instagram, Twitter, Facebook } from 'lucide-react';

export function Footer() {
  const importantLinks = [
    'About us',
    'Contact us',
    'Privacy Policy',
    'Terms of use',
    'Refund Policy'
  ];

  return (
    <footer className="bg-gray-100 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Logo and Description */}
          <div className="md:col-span-1">
            <h3 className="text-xl font-bold text-gray-900 mb-4">CleanCare</h3>
            <p className="text-gray-600 text-sm leading-relaxed">
              About Us<br />
              CleanCare is India's Top Rated<br />
              Online Laundry Service & Garment<br />
              Care Brand.
            </p>
          </div>

          {/* Important Links */}
          <div className="md:col-span-1">
            <h4 className="font-semibold text-gray-900 mb-4">Important Links</h4>
            <ul className="space-y-2">
              {importantLinks.map((link, index) => (
                <li key={index}>
                  <a href="#" className="text-gray-600 hover:text-blue-600 text-sm transition-colors">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div className="md:col-span-1">
            <h4 className="font-semibold text-gray-900 mb-4">Contact</h4>
            <div className="text-gray-600 text-sm space-y-2">
              <p>Call us at:</p>
              <p className="font-semibold">+91 81 234 56789</p>
            </div>
          </div>

          {/* Follow Us */}
          <div className="md:col-span-1">
            <h4 className="font-semibold text-gray-900 mb-4">Follow Us</h4>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-600 hover:text-blue-600 transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-600 hover:text-blue-600 transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-600 hover:text-blue-600 transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-gray-200 mt-8 pt-8 text-center">
          <p className="text-gray-600 text-sm">
            © 2024 CleanCare. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}