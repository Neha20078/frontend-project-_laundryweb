
  # Laundry Service Web App

  This is a code bundle for Laundry Service Web App. The original project is available at https://www.figma.com/design/qtkV7vKHPD5cUlbOjK8ZxZ/Laundry-Service-Web-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  